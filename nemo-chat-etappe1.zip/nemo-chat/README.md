# Nemo Chat (Etappe 1)

Eigener Chat mit NVIDIA Nemotron 3 Ultra. Läuft kostenlos auf Cloudflare Workers, installierbar unter Windows und Android.

## Einrichten (ohne Terminal)
1. Neues **öffentliches** GitHub-Repository anlegen und alle Dateien dieses Ordners hochladen (Drag & Drop im Browser). Dein Key steht nicht im Code.
2. Öffne `https://deploy.workers.cloudflare.com/?url=https://github.com/DEIN-NAME/DEIN-REPO` (Repo-URL anpassen), melde dich bei Cloudflare an (kostenlos), verbinde GitHub.
3. Trage `NVIDIA_API_KEY` (dein nvapi-Key) und `APP_PASSWORD` (frei wählbar) ein und starte das Deployment.
4. Öffne die angezeigte `…workers.dev`-Adresse, gib das Passwort ein (Einstellungen), teste die Verbindung.

## Einrichten (Terminal, Node.js nötig)
```
npm install
npx wrangler login
npx wrangler deploy
npx wrangler secret put NVIDIA_API_KEY
npx wrangler secret put APP_PASSWORD
```

## Als App installieren
- Windows: in Edge oder Chrome auf das Installieren-Symbol in der Adressleiste klicken.
- Android: in Chrome Menü → „App installieren“.

## Fehlersuche
- 401: Passwort falsch.
- 403 von NVIDIA: Key prüfen und ob dein NVIDIA-Konto die Freigabe „Public API Endpoints“ hat.
- Chats liegen in Etappe 1 nur lokal auf dem jeweiligen Gerät (Sync folgt in Etappe 5).
