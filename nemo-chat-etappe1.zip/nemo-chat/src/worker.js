const BASE = 'https://integrate.api.nvidia.com/v1';
const MODEL = 'nvidia/nemotron-3-ultra-550b-a55b';
const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });

async function authed(req, env) {
  if (!env.APP_PASSWORD) return false;
  const given = (req.headers.get('authorization') || '').replace(/^Bearer /, '');
  const enc = new TextEncoder();
  const [a, b] = await Promise.all([given, env.APP_PASSWORD].map(s => crypto.subtle.digest('SHA-256', enc.encode(s))));
  return crypto.subtle.timingSafeEqual(a, b);
}

export default {
  async fetch(req, env) {
    const { pathname } = new URL(req.url);
    if (!pathname.startsWith('/api/')) return env.ASSETS.fetch(req);
    if (!(await authed(req, env))) return J({ error: 'Passwort fehlt oder ist falsch.' }, 401);
    if (pathname === '/api/ping') return J({ ok: true, nvidiaKey: !!env.NVIDIA_API_KEY, model: MODEL });
    if (pathname === '/api/chat' && req.method === 'POST') {
      if (!env.NVIDIA_API_KEY) return J({ error: 'NVIDIA_API_KEY ist in Cloudflare nicht gesetzt.' }, 500);
      let body;
      try { body = await req.json(); } catch { return J({ error: 'Ungültige Anfrage.' }, 400); }
      body.model ||= MODEL;
      let up;
      try {
        up = await fetch(BASE + '/chat/completions', {
          method: 'POST', signal: req.signal,
          headers: { authorization: 'Bearer ' + env.NVIDIA_API_KEY, 'content-type': 'application/json', accept: body.stream ? 'text/event-stream' : 'application/json' },
          body: JSON.stringify(body)
        });
      } catch (e) { return J({ error: 'NVIDIA nicht erreichbar: ' + e.message }, 502); }
      return new Response(up.body, { status: up.status, headers: { 'content-type': up.headers.get('content-type') || 'application/json', 'cache-control': 'no-store' } });
    }
    return J({ error: 'Nicht gefunden.' }, 404);
  }
};
